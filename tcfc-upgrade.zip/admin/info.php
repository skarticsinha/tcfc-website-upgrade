<?php
    phpinfo();
    ?>